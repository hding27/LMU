// EasyDLL.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "math.h"
#define M_PI 3.14159

//Function declarations
extern "C" __declspec(dllexport) int __cdecl GetSphereSAandVol(double radius, double* sa, double* vol);
double GetSA(double radius);
double GetVol(double radius);

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

__declspec(dllexport) int __cdecl GetSphereSAandVol(double radius, double* sa, double* vol)
//Calculate the surface area and volume of a sphere with given radius
{
   if(radius < 0)
   return false; //return false (0) if radius is negative
       *sa = GetSA(radius);
       *vol = GetVol(radius);
       return true;
}

double GetSA(double radius)
{
   return 4 * M_PI * radius * radius;
}

double GetVol(double radius)
{
   return 4.0/3.0 * M_PI * pow(radius, 3.0);
}



